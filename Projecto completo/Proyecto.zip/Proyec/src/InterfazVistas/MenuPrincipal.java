
package InterfazVistas;

import Modelo.*;
import Control.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class MenuPrincipal extends javax.swing.JFrame {
       ControlUsser Cusser = new ControlUsser();
    Usuarios  Usuario = new Usuarios("llll", "ssss", "2121", 18, 123456, "peresx");
    UserAdmin Ua = new UserAdmin();

    /**
     * Creates new form MenuPrincipal
     */
    public MenuPrincipal() {
        initComponents();
        this.setExtendedState(6);
        setLocationRelativeTo(null);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        CerrarjButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        UsuariojTextField = new javax.swing.JTextField();
        IniciarjButton = new javax.swing.JButton();
        RegistrarsejButton1 = new javax.swing.JButton();
        BienvenidajLabel = new javax.swing.JLabel();
        ContrasnajPasswordField = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(102, 255, 102));
        jPanel1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N

        CerrarjButton.setBackground(new java.awt.Color(255, 204, 204));
        CerrarjButton.setForeground(new java.awt.Color(0, 0, 0));
        CerrarjButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/close.png"))); // NOI18N
        CerrarjButton.setText("CerrarApp");
        CerrarjButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CerrarjButtonActionPerformed(evt);
            }
        });

        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/user.png"))); // NOI18N
        jLabel1.setText("      Usuario");

        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/hide.png"))); // NOI18N
        jLabel2.setText("     Cantraseña");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        UsuariojTextField.setBackground(new java.awt.Color(204, 204, 204));
        UsuariojTextField.setForeground(new java.awt.Color(0, 0, 0));
        UsuariojTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UsuariojTextFieldActionPerformed(evt);
            }
        });

        IniciarjButton.setBackground(new java.awt.Color(0, 255, 204));
        IniciarjButton.setForeground(new java.awt.Color(51, 51, 51));
        IniciarjButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/play.png"))); // NOI18N
        IniciarjButton.setText("Iniciar");
        IniciarjButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IniciarjButtonActionPerformed(evt);
            }
        });

        RegistrarsejButton1.setBackground(new java.awt.Color(0, 255, 204));
        RegistrarsejButton1.setForeground(new java.awt.Color(0, 0, 0));
        RegistrarsejButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/edit.png"))); // NOI18N
        RegistrarsejButton1.setText("Registrarse");
        RegistrarsejButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegistrarsejButton1ActionPerformed(evt);
            }
        });

        BienvenidajLabel.setBackground(new java.awt.Color(204, 204, 255));
        BienvenidajLabel.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        BienvenidajLabel.setForeground(new java.awt.Color(0, 0, 0));
        BienvenidajLabel.setText("                Bienvenido a nuestro sistema");

        ContrasnajPasswordField.setBackground(new java.awt.Color(204, 204, 204));
        ContrasnajPasswordField.setForeground(new java.awt.Color(0, 0, 0));
        ContrasnajPasswordField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContrasnajPasswordFieldActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(CerrarjButton)
                .addGap(18, 18, 18)
                .addComponent(BienvenidajLabel)
                .addGap(0, 178, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(94, 94, 94)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(RegistrarsejButton1)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(IniciarjButton, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(UsuariojTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                        .addComponent(ContrasnajPasswordField)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(BienvenidajLabel))
                    .addComponent(CerrarjButton, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(UsuariojTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(ContrasnajPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(47, 47, 47)
                .addComponent(IniciarjButton)
                .addGap(27, 27, 27)
                .addComponent(RegistrarsejButton1)
                .addContainerGap(106, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void ValidarInicio ( ){
    String nombreUsuario = UsuariojTextField.getText();
    String contrasena = new String(ContrasnajPasswordField.getPassword());

    Cusser.LeersArchivo();

    boolean encontrado = false;
    
    for (Usuarios user : ControlUsser.getLisUsuarios()) {
        if (user.getNombre().equals(nombreUsuario) && user.getContrasna().equals(contrasena)) {
            encontrado = true;
            JOptionPane.showMessageDialog(this, "Inicio de sesión exitoso");
            Ua.setVisible(true);
            Ua.setVmnp(this);
            this.setVisible(false);
            break;
        }
    }

    if (!encontrado) {
        JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos");
    }
}

    
        
    private void CerrarjButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CerrarjButtonActionPerformed
      System.exit(0);
    }//GEN-LAST:event_CerrarjButtonActionPerformed

    private void UsuariojTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UsuariojTextFieldActionPerformed
       
    }//GEN-LAST:event_UsuariojTextFieldActionPerformed

    private void IniciarjButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IniciarjButtonActionPerformed
     ValidarInicio();
     
    }//GEN-LAST:event_IniciarjButtonActionPerformed

    private void RegistrarsejButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegistrarsejButton1ActionPerformed
        MenuRegistrarse mnr = new MenuRegistrarse();
        mnr.setmnp(this);
        mnr.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_RegistrarsejButton1ActionPerformed

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel2MouseClicked

    private void ContrasnajPasswordFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContrasnajPasswordFieldActionPerformed
//        if (User.getContrasna()) {
//            User.equals()
//        } else {
//        }
      
    }//GEN-LAST:event_ContrasnajPasswordFieldActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        ControlUsser Cusser = new ControlUsser();
        
  
     Cusser.CargarArchivo();
    
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MenuPrincipal().setVisible(true);
            }
            });

       
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BienvenidajLabel;
    private javax.swing.JButton CerrarjButton;
    private javax.swing.JPasswordField ContrasnajPasswordField;
    private javax.swing.JButton IniciarjButton;
    private javax.swing.JButton RegistrarsejButton1;
    private javax.swing.JTextField UsuariojTextField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
