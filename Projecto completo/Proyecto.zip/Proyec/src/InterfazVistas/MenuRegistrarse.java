
package InterfazVistas;

import Modelo.*;
import Control.*;
import javax.swing.*;


public class MenuRegistrarse extends javax.swing.JFrame {
     
       ControlUsser Cusser = new ControlUsser();
    private MenuPrincipal mnp;

    public MenuRegistrarse() {
        initComponents();
         this.setExtendedState(6);
        setLocationRelativeTo(null);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        RegresarjButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        RegistrarjButton = new javax.swing.JButton();
        NombrejTextField = new javax.swing.JTextField();
        ApellidosjTextField = new javax.swing.JTextField();
        CorreoEjTextField = new javax.swing.JTextField();
        IdentificacionjTextField = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        ContraseñajPasswordField = new javax.swing.JPasswordField();
        ComfirmarcontrajPasswordField = new javax.swing.JPasswordField();
        CelularjTextField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(51, 255, 51));

        RegresarjButton.setBackground(new java.awt.Color(204, 204, 204));
        RegresarjButton.setForeground(new java.awt.Color(0, 0, 0));
        RegresarjButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/back.png"))); // NOI18N
        RegresarjButton.setText("Regresar");
        RegresarjButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegresarjButtonActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(153, 153, 153));
        jLabel1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Ya te puedes registrar");

        jLabel2.setBackground(new java.awt.Color(153, 153, 153));
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("    Nombre");

        jLabel3.setBackground(new java.awt.Color(153, 153, 153));
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("    Apellidos");

        jLabel4.setBackground(new java.awt.Color(153, 153, 153));
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("    Identificasion");

        jLabel5.setBackground(new java.awt.Color(153, 153, 153));
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Celular");

        jLabel6.setBackground(new java.awt.Color(153, 153, 153));
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Coreo electronico");

        RegistrarjButton.setBackground(new java.awt.Color(153, 153, 153));
        RegistrarjButton.setForeground(new java.awt.Color(0, 0, 0));
        RegistrarjButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/play.png"))); // NOI18N
        RegistrarjButton.setText("Registrar");
        RegistrarjButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegistrarjButtonActionPerformed(evt);
            }
        });

        NombrejTextField.setBackground(new java.awt.Color(153, 153, 153));
        NombrejTextField.setForeground(new java.awt.Color(0, 0, 0));
        NombrejTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombrejTextFieldActionPerformed(evt);
            }
        });

        ApellidosjTextField.setBackground(new java.awt.Color(153, 153, 153));
        ApellidosjTextField.setForeground(new java.awt.Color(0, 0, 0));

        CorreoEjTextField.setBackground(new java.awt.Color(153, 153, 153));
        CorreoEjTextField.setForeground(new java.awt.Color(0, 0, 0));
        CorreoEjTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CorreoEjTextFieldActionPerformed(evt);
            }
        });

        IdentificacionjTextField.setBackground(new java.awt.Color(153, 153, 153));
        IdentificacionjTextField.setForeground(new java.awt.Color(0, 0, 0));
        IdentificacionjTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IdentificacionjTextFieldActionPerformed(evt);
            }
        });

        jLabel7.setBackground(new java.awt.Color(204, 204, 204));
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText(" contraseña");

        jLabel8.setBackground(new java.awt.Color(204, 204, 204));
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Confirmar contraseña");

        ContraseñajPasswordField.setBackground(new java.awt.Color(153, 153, 153));
        ContraseñajPasswordField.setForeground(new java.awt.Color(0, 0, 0));

        ComfirmarcontrajPasswordField.setBackground(new java.awt.Color(153, 153, 153));
        ComfirmarcontrajPasswordField.setForeground(new java.awt.Color(0, 0, 0));

        CelularjTextField.setBackground(new java.awt.Color(153, 153, 153));
        CelularjTextField.setForeground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(RegresarjButton)
                .addGap(74, 74, 74)
                .addComponent(jLabel1)
                .addGap(0, 76, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel6)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel8))
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(RegistrarjButton)
                    .addComponent(CorreoEjTextField)
                    .addComponent(IdentificacionjTextField)
                    .addComponent(ApellidosjTextField)
                    .addComponent(NombrejTextField)
                    .addComponent(ContraseñajPasswordField, javax.swing.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE)
                    .addComponent(ComfirmarcontrajPasswordField)
                    .addComponent(CelularjTextField))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel1))
                    .addComponent(RegresarjButton))
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(NombrejTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(ContraseñajPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel8)
                    .addComponent(ComfirmarcontrajPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ApellidosjTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(IdentificacionjTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(CelularjTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CorreoEjTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(35, 35, 35)
                .addComponent(RegistrarjButton)
                .addGap(26, 26, 26))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
// verificar q las contraseñas coinsidan
    public  Boolean  Coincidencia (){

         String contraseña = new String(ContraseñajPasswordField.getPassword());
         String Confirmar = new String(ComfirmarcontrajPasswordField.getPassword());
return  contraseña.equals(Confirmar);
    }
   // metodo para pasar de pesta jframe 
    public  void setmnp (MenuPrincipal mnp){
    this.mnp = mnp;
}
    private void RegresarjButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegresarjButtonActionPerformed
    mnp.setVisible(true);
    this.setVisible(false);
    }//GEN-LAST:event_RegresarjButtonActionPerformed

    private void RegistrarjButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegistrarjButtonActionPerformed
        if (Coincidencia()) {
         String NombreUser = NombrejTextField.getText();
         String ApellidosUser = ApellidosjTextField.getText();
         String contraseña = new String(ContraseñajPasswordField.getPassword());
         String Correo = CorreoEjTextField.getText(); 
         String identificasion = IdentificacionjTextField.getText();
         String Celulsr = CelularjTextField.getText();
            
         Usuarios nuevoUser = new Usuarios(NombreUser, ApellidosUser, contraseña, ERROR, ICONIFIED, Correo);
         ControlUsser.LisUsuarios.add(nuevoUser);
         Cusser.EscribirEnArchivo();
         Cusser.GuadarEnArchivo();
         
         
         JOptionPane.showMessageDialog(null, " usuario Registrado");
        } else {
            JOptionPane.showMessageDialog(null," error al registrarse");
        }
        
        
        mnp.setVisible(true);
        this.setVisible(false);
         
    }//GEN-LAST:event_RegistrarjButtonActionPerformed

    private void CorreoEjTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CorreoEjTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CorreoEjTextFieldActionPerformed

    private void NombrejTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombrejTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombrejTextFieldActionPerformed

    private void IdentificacionjTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IdentificacionjTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IdentificacionjTextFieldActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuRegistrarse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuRegistrarse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuRegistrarse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuRegistrarse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuRegistrarse().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ApellidosjTextField;
    private javax.swing.JTextField CelularjTextField;
    private javax.swing.JPasswordField ComfirmarcontrajPasswordField;
    private javax.swing.JPasswordField ContraseñajPasswordField;
    private javax.swing.JTextField CorreoEjTextField;
    private javax.swing.JTextField IdentificacionjTextField;
    private javax.swing.JTextField NombrejTextField;
    private javax.swing.JButton RegistrarjButton;
    private javax.swing.JButton RegresarjButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
