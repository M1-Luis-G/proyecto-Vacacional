
package AstracInterface;

public abstract class Informacion {
    
    public abstract String detalles();
}
