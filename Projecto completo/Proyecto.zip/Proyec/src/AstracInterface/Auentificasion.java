
package AstracInterface;


public interface Auentificasion{
    
    public double Autentificar ();
    
}
