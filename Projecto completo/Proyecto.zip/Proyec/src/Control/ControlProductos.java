
package Control;

import javax.swing.*;
import java.io.*;
import java.util.*;
import AstracInterface.*;
import Modelo.*;

public class ControlProductos extends Informacion implements Auentificasion{

    private static ArrayList<Productos> lisProductos = new ArrayList<>();
   private final String Archivopro = "\\Users\\luisa\\OneDrive\\ MisProductos";
   
      public void RegistrarProductos (Productos p){
        lisProductos.add(p);
        GuadarEnArchivoP();
    }
     public void ListarProductos (){
        if (lisProductos.isEmpty()) {
               JOptionPane.showInputDialog("No hay usuarios disponible");
        } else {
            JOptionPane.showInputDialog("th");
                for (Productos p : lisProductos){
                JOptionPane.showInputDialog(p);
                }
        }
    }
     // sobrecarca de metodos 
    public Productos BuscarProducto ( String Nombre){
        for ( Productos p : lisProductos){
            if (p.getNombre().equalsIgnoreCase(Nombre)) {
             return p;
            }
        }
        return null;
    } 

        public Productos BuscarProducto ( String Marca, int FechaIngreso){
        for ( Productos p : lisProductos){
            if (p.getMarca().equalsIgnoreCase(Marca)) {
             return p;
            }
        }
        return null;
    }
                public void AtualizarProductos (String Nombre,  double NuevoPrecio, int nuevaCantidad){
            Productos p = BuscarProducto(Nombre);
            if (p != null) {
                p.setPrecio(NuevoPrecio);
                p.setCantidad(nuevaCantidad);
            JOptionPane.showInputDialog("Producto Actualisado");
            } else {
            }JOptionPane.showInputDialog("no se encontro el produdto");
        }
       public void EliminarProducto( String Nombre){
            Productos p = BuscarProducto(Nombre);
            if (p != null) {
                lisProductos.remove(p);
                GuadarEnArchivoP();
                
                System.out.println("Juego eliminado");
            } else {System.out.println(" Videojuego no encontrado");
            }
        }
       // metodos para los archivos
       
    public void crearArchivo() {
        try {
            File Archivo = new File("\\Users\\luisa\\OneDrive\\ MisProductos");
            if (Archivo.createNewFile()) {
                JOptionPane.showMessageDialog(null, "arcvicocreado  " + Archivo.getName());
            } else {
                JOptionPane.showMessageDialog(null, "error el Archivo ya exixte");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "error al crear el archivo");
            e.printStackTrace();
        }
    }
       public void EscribirEnArchivo() {
        try {
            FileWriter ela = new FileWriter("\\Users\\luisa\\OneDrive\\ MisProductos" );
            ela.write("");
            ela.close();
           
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, " error ");
            e.printStackTrace();

        }
    }
       
    public void GuadarEnArchivoP() {

    try (BufferedWriter writer = new BufferedWriter(new FileWriter("\\Users\\luisa\\OneDrive\\ MisProductos"))) {
        for (Productos p : lisProductos) {
            writer.write(p.topCSV());
            writer.newLine();  
          }
       JOptionPane.showMessageDialog(null, " producto guardado"); 
    } catch (IOException e) {
        JOptionPane.showMessageDialog(null,"Error al guardar productos: " );
    }
    }
     public void CargarArchivo() {
        lisProductos.size();
        File Line = new File("\\Users\\luisa\\OneDrive\\ MisProductos");
        if (Line.exists()) {
            return;
        }
        try (BufferedReader MAJ = new BufferedReader(new FileReader("\\Users\\luisa\\OneDrive\\ MisProductos"))) {
            String linea;
            while ((linea = MAJ.readLine()) != null) {
                lisProductos.add(Productos.fromCSV(linea));
            }
            JOptionPane.showMessageDialog(null,"");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null," Error al cargar el archivo");
        }
    }
    

    public static ArrayList<Productos> getLisProductos() {
        return lisProductos;
    }

   
     
    @Override
    public double Autentificar() {
     for (Productos p : lisProductos){
         if ( p == lisProductos.clone() ) {
             lisProductos.remove(p);
          JOptionPane.showMessageDialog(null, "producto eliminado");
         } else {
             JOptionPane.showMessageDialog(null, " no se  encontraron productos clonados");
                    } }
     throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String detalles() {
        
     for ( Productos productos :lisProductos){
        JOptionPane.showMessageDialog(null, productos);
     }
     
       

        throw new UnsupportedOperationException(""); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
