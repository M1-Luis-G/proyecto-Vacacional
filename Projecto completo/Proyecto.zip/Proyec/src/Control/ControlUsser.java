package Control;

import javax.swing.*;
import java.io.*;
import java.util.*;
import AstracInterface.*;
import Modelo.*;

public class ControlUsser extends Informacion implements Auentificasion {
     
          public final String Archivo = "\\Users\\luisa\\OneDrive\\ MyArchivo";
            public static ArrayList<Usuarios> LisUsuarios = new ArrayList<>();

    public void RegistrarUsuario(Usuarios U) {

        LisUsuarios.add(U);
        GuadarEnArchivo();
    }

    public void ListarUsuarios() {
        if (LisUsuarios.isEmpty()) {
            JOptionPane.showInputDialog("No hay usuarios disponible");
        } else {
            JOptionPane.showInputDialog("th");
            for (Usuarios u : LisUsuarios) {
                JOptionPane.showInputDialog(u);
            }
        }
    }
    

    public void crearArchivo() {
        try {
            File Archivo = new File("\\Users\\luisa\\OneDrive\\ MyArchivo");
            if (Archivo.createNewFile()) {
                JOptionPane.showMessageDialog(null, "arcvicocreado  " + Archivo.getName());
            } else {
                JOptionPane.showMessageDialog(null, "error el Archivo ya exixte");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "error al crear el archivo");
            e.printStackTrace();
        }

    }

    public void EscribirEnArchivo() {
        try {
            FileWriter Ela = new FileWriter("\\Users\\luisa\\OneDrive\\ MyArchivo" );
            Ela.write("");
            Ela.close();
         
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, " error ");
            e.printStackTrace();

        }
    }
    public void LeersArchivo(){ 
        File MyArchivo = new File("\\Users\\luisa\\OneDrive\\ MyArchivo");
        if (!MyArchivo.exists()) {
            JOptionPane.showMessageDialog(null,"Archivo no existe: " + MyArchivo.getAbsolutePath());
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(MyArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(";");
                if (datos.length == 6) {
                    Usuarios user = new Usuarios(datos[0], datos[1], datos[2],
                            Integer.parseInt(datos[3]), Integer.parseInt(datos[4]), datos[5]);
                    LisUsuarios.add(user);
                }
            }
        } catch (IOException e) {
            System.out.println("Error al leer archivo: " + e.getMessage());
        }
    }
        public void Uesuariocreado() {
        File archivo = new File(Archivo);
        if (!archivo.exists()) {
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {
                bw.write("llll;ssss;2121;18;123456;peresx");
                bw.newLine();
                System.out.println("");
            } catch (IOException e) {
                System.out.println("Error al crear archivo: " + e.getMessage());
            }
        }
    }

    

    // Metodo para guardar el los archivos
    public void GuadarEnArchivo() {

    try (BufferedWriter writer = new BufferedWriter(new FileWriter("\\Users\\luisa\\OneDrive\\ MyArchivo"))) {
        for (Usuarios u : LisUsuarios) {
            writer.write(u.TopCSV());
            writer.newLine();  
        }
        System.out.println("Usuarios guardados correctamente en " + Archivo);
    } catch (IOException e) {
        System.out.println("Error al guardar usuarios: " + e.getMessage());
    }
    }
    // metodo para Cargar Archivos

    public void CargarArchivo() {
        LisUsuarios.size();
        File Line = new File("\\Users\\luisa\\OneDrive\\ MyArchivo ");
        if (Line.exists()) {
            return;
        }
        try (BufferedReader MAJ = new BufferedReader(new FileReader("\\Users\\luisa\\OneDrive\\ MyArchivo"))) {
            String linea;
            while ((linea = MAJ.readLine()) != null) {
                LisUsuarios.add(Usuarios.fromCSV(linea));
            }
            JOptionPane.showMessageDialog(null,"");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null," Error al cargar el archivo");
        }
    }

    public static ArrayList<Usuarios> getLisUsuarios() {
        return LisUsuarios;
    }

    @Override
    public double Autentificar() {
            for (Usuarios u : LisUsuarios){
         if ( u == LisUsuarios.clone() ) {
             LisUsuarios.remove(u);
          JOptionPane.showMessageDialog(null, "Usuario eliminado");
         } else {
             JOptionPane.showMessageDialog(null, " no se  encontraron Usuarios clonados");
                    } }
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String detalles() {
       for (Usuarios usuarios: LisUsuarios){
          JOptionPane.showMessageDialog(null, usuarios);
        
    }
        
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
