package Modelo;

public class Productos {

    private String Nombre;
    private String Marca;
    private String Sabor;
    private double Precio;
    private int FechaIngreso;
    private int Cantidad;

    public Productos(String Nombre, String Marca, String Sabor, double Precio, int FechaIngreso, int Cantidad) {
        this.Nombre = Nombre;
        this.Marca = Marca;
        this.Sabor = Sabor;
        this.Precio = Precio;
        this.FechaIngreso = FechaIngreso;
        this.Cantidad = Cantidad;
    }
        public String topCSV (){
        return  Nombre + ";" + Marca + ";" + Sabor + ";" + Precio + ";" + FechaIngreso + ";" + Cantidad +"," ;
    }
    public static Productos fromCSV (String linea){
        String[]Partes = linea.split(";");
        return new Productos(Partes[0], Partes[1], Partes[2],Double.parseDouble(Partes[3]), Integer.parseInt(Partes[4]), Integer.parseInt(Partes[5]));
    }
    
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public void setSabor(String Sabor) {
        this.Sabor = Sabor;
    }

    public double getPrecio() {
        return Precio;
    }

    public void setPrecio(double Precio) {
        this.Precio = Precio;
    }

    public void setFechaIngreso(int FechaIngreso) {
        this.FechaIngreso = FechaIngreso;
    }

    public void setCantidad(int Cantidad) {
        this.Cantidad = Cantidad;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getMarca() {
        return Marca;
    }

    public String getSabor() {
        return Sabor;
    }

    public int getFechaIngreso() {
        return FechaIngreso;
    }

    @Override
    public String toString() {
        return "Productos{" + "Nombre=" + Nombre
                + ", Marca=" + Marca
                + ", Sabor=" + Sabor
                + ", Precio=" + Precio
                + ", FechaIngreso="
                + FechaIngreso
                + ", Cantidad=" + Cantidad + '}';
    }

}
