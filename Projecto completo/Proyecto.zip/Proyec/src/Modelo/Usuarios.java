package Modelo;

public class Usuarios {

    private String Nombre;
    private String Apellidos;
    private String Contrasna;
    private int Celular;
    private int identificasion;
    private String CorreoEletronico;

    public Usuarios(String Nombre, String Apellidos, String Contrasna, int Celular, int identificasion, String CorreoEletronico) {
        this.Nombre = Nombre;
        this.Apellidos = Apellidos;
        this.Contrasna = Contrasna;
        this.Celular = Celular;
        this.identificasion = identificasion;
        this.CorreoEletronico = CorreoEletronico;
    }


    public Usuarios() {
    }
    
      
    public String TopCSV (){
        return  Nombre + ";" + Apellidos + ";" + Contrasna + ";" + Celular + ";" + identificasion + ";" + CorreoEletronico + ";" ;
    }
    public static Usuarios fromCSV (String linea){
        String[]Partes = linea.split(";");
        return new Usuarios(Partes[0], Partes[1], Partes[2], Integer.parseInt(Partes [3]),Integer.parseInt(Partes[4]), Partes[5]);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Usuarios{");
        sb.append("Nombre=").append(Nombre);
        sb.append(", Apellidos=").append(Apellidos);
        sb.append(", Contrasna=").append(Contrasna);
        sb.append(", Celular=").append(Celular);
        sb.append(", identificasion=").append(identificasion);
        sb.append(", CorreoEletronico=").append(CorreoEletronico);
        sb.append('}');
        return sb.toString();
    }

    public String getNombre() {
        return Nombre;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public String getContrasna() {
        return Contrasna;
    }

    public int getCelular() {
        return Celular;
    }

    public int getIdentificasion() {
        return identificasion;
    }

    public String getCorreoEletronico() {
        return CorreoEletronico;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    public void setContrasna(String Contrasna) {
        this.Contrasna = Contrasna;
    }

    public void setEdad(int Celular) {
        this.Celular = Celular;
    }

    public void setIdentificasion(int identificasion) {
        this.identificasion = identificasion;
    }

    public void setCorreoEletronico(String CorreoEletronico) {
        this.CorreoEletronico = CorreoEletronico;
    }

}
